#define PIPE_READ 0
#define PIPE_WRITE 1
#define STD_INPUT 0
#define STD_OUTPUT 1
